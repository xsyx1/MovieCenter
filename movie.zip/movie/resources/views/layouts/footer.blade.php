<footer class="footer">
    <div class="container-fluid">
        <div class="copyright">
            © {{ date('Y') }} Copyright  Sabor e Saúde
        </div>
    </div>
</footer>
