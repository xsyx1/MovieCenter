@if ($errors->has($field))
    <span style="color: white" class="invalid-feedback" role="alert">{{ $errors->first($field) }}</span>
@endif
