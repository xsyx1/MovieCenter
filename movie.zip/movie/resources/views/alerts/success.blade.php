@if (session($key ?? 'status'))
<div style="color: white" class="alert alert-success alert-dismissible show" role="alert">
    {{ session($key ?? 'status') }}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <i class="tim-icons icon-simple-remove"></i>
    </button>
</div>
@endif
