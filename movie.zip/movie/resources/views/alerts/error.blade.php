@if (session($key ?? 'error'))
<div style="color: white" class="alert alert-danger alert-dismissible show" role="alert">
    {{ session($key ?? 'error') }}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <i class="tim-icons icon-simple-remove"></i>
    </button>
</div>
@endif
