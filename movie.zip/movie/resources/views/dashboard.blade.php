@extends('layouts.app', ['pageSlug' => 'dashboard'])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="container">
				<div class="row">
					<div class="container">
						<div class="row">
						    @include('alerts.success')
                			@include('alerts.error')
						    <div class="col-md-12">
						    	@forelse ($data as $item)
					    		<div class="card mb col-md-4">
					              <img class="card-img-top" src="{{ asset('images/banner.png') }}" alt="Card image cap">
					              <div class="card-body mb">
					              <table>
					                <h5 class="text-center card-title">{{$item->name }}</h5>
					                <p class="text-center card-text">Gênero: {{$item->opGenre($item->genre)}}</p>
									<p class="text-center card-text">Data de Lançamento: <br/>{{carbon($item->date)->format('d/m/Y')}}</p>
									<p class="text-center card-text">Nota: {{$item->score}}</p>
					                <hr>
					                	<a class="btn btn-danger mb" type="button" href="#">Assistir</a>
					            	</table>
					              </div>
					            </div>
					            @empty
					            <div class=" col-md-12" style="display: flex; left: 100%">
					            	<div class="card-body mb">
                                		<h1 class="fas fa-ban"></h1>
                                		<h1 class="card-text" style="text-align: center; font-size: 1.1em;">
                                    		Nenhuma Filme cadastrado.
                                		</h1>
                                	</div>
                            	</div>
                            @endforelse
					        </div>
						</div>
					</div>
				</div>
			</div>
        </div>
    </div>
@endsection
