<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TrackCash</title>
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <style>
        :root {
            --input-padding-x: 1.5rem;
            --input-padding-y: 0.75rem;
        }

        body {
            font-family: "Poppins", sans-serif;
            font-size: 0.875rem;
            font-weight: 400;
            line-height: 1.5;
            color: #495057;
            text-align: left;
        }

        .modalrec {
            z-index: -1000;
            margin: 100px 0px 0px 0;
        }

        .login,
        .image {
            width: 100%;
            min-height: 100vh;
        }

        .img-logo {
            width: 50%;
            margin-left: 120px;
        }


        .bg-image {
            background-image: url('{{ asset("images/movie-banner.PNG") }}');
            background-size: cover;
            background-position: center;

        }

        .login-heading {
            font-weight: bold;
            color: #C94A21;
            margin: 30px 0;
            font-size: 24px; 
            font-family: "Ubuntu", sans-serif;
            box-sizing: border-box;
        }

        .par-heading {
            font-size: 12px; 
            font-family: "Ubuntu", sans-serif;
        }

        .btn-login {
            font-size: 0.9rem;
            letter-spacing: 0.05rem;
            padding: 0.75rem 1rem;
            border-radius: 1.5rem;
            background: DarkRed;
            border-color: DarkRed;
        }

        .btn-login:hover {
            background: #C94A21;
            border-color: #C94A21;
        }

        .form-label-group {
            position: relative;
            margin-bottom: 0.5rem;
        }

        .form-label-group>input,
        .form-label-group>label {
            padding: var(--input-padding-y) var(--input-padding-x);
            height: auto;
            border-radius: 0.5rem;
        }

        .form-label-group>label {
            position: absolute;
            top: 0;
            left: 0;
            display: block;
            width: 100%;
            margin-bottom: 0;
            /* Override default `<label>` margin */
            line-height: 1.5;
            color: #495057;
            cursor: text;
            /* Match the input under the label */
            border: 1px solid transparent;
            border-radius: .25rem;
            transition: all .1s ease-in-out;
        }

        .form-label-group input::-webkit-input-placeholder {
            color: transparent;
        }

        .form-label-group input:-ms-input-placeholder {
            color: transparent;
        }

        .form-label-group input::-ms-input-placeholder {
            color: transparent;
        }

        .form-label-group input::-moz-placeholder {
            color: transparent;
        }

        .form-label-group input::placeholder {
            color: transparent;
        }

        .form-label-group input:not(:placeholder-shown) {
            padding-top: calc(var(--input-padding-y) + var(--input-padding-y) * (2 / 3));
            padding-bottom: calc(var(--input-padding-y) / 3);
        }

        .form-label-group input:not(:placeholder-shown)~label {
            padding-top: calc(var(--input-padding-y) / 3);
            padding-bottom: calc(var(--input-padding-y) / 3);
            font-size: 12px;
            color: #777;
        }

        /* Fallback for Edge
    -------------------------------------------------- */

        @supports (-ms-ime-align: auto) {
            .form-label-group>label {
                display: none;
            }

            .form-label-group input::-ms-input-placeholder {
                color: #777;
            }
        }

        /* Fallback for IE
    -------------------------------------------------- */

        @media all and (-ms-high-contrast: none),
        (-ms-high-contrast: active) {
            .form-label-group>label {
                display: none;
            }

            .form-label-group input:-ms-input-placeholder {
                color: #777;
            }
        }
    </style>
</head>

<body>
    
    <form class="form" method="post" action="{{ route('login') }}">
        @csrf
        <div class="container-fluid">
            <div class="row no-gutter">
                <div class="col-md-8 col-lg-6">
                    <div class="login d-flex align-items-center py-5">
                        <div class="container">
                            <div class="row">
                                <div class="div-logo col-md-9 col-lg-8 mx-auto">
                                    <img src="{{ asset('images/movie-logo.png') }}" alt="Logo" class="img-fluid img-logo" >
                                    <h4 style="color: DarkRed;" class=" text-center login-heading mb-4">Entrar na Movie</h4>
                                    <form>
                                        <div class="form-group">

                                            <input type="email" name="email" id="inputEmail" style="background-color: #E5E5E5;"
                                                class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}"
                                                placeholder="Digite seu email" value="{{ old('email') }}" required autofocus>
                                            @include('alerts.feedback', ['field' => 'email'])
                                        </div>

                                        <div class="form-group">
                                            <input type="password" id="inputPassword" placeholder="Digite sua senha"
                                                name="password" style="background-color: #E5E5E5;"
                                                class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}"
                                                required>
                                            @include('alerts.feedback', ['field' => 'password'])
                                        </div>

                                        
                                        <button
                                            class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2"
                                            type="submit">Acessar o sistema</button>
                                    
                                        <div style=" width: 150px;"class="custom-control custom-checkbox mb-3">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1">
                                            <label style="color: #C94A21;" class="custom-control-label" for="customCheck1">Lembrar-me</label>
                                        </div>
                                        <div style="position:relative; top: -40px;" class="text-right">
                                            <a style=" color: #C94A21;" class="small" id="rec" type="button" data-toggle="modal" data-target="#myModal">
                                                Recuperar Senha
                                            </a>
                                        </div>
                                        <div style="position:relative; top: -35px;" class="text-right">
                                            <a style="color: #C94A21;" class="small" href="{{ route('register') }}">Cadastre-se</a>
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image"></div>
            </div>
        </div>
    </form>
</body>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
    integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
    integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>
<!-- modal -->
<div class="d-flex justify-content-center modalrec modal fade bd-example-modal-lg" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" style="width: 400px;">
      <div class="modal-content">
        <div class="col-md-12 col-lg-12 mx-auto">
            <button style="margin: 15px 0px 0px 0px; " type="button" id="close" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            <h4 class=" text-center login-heading mb-4">Recuperar senha</h4>
            <p  class="text-center par-heading">Digite abaixo seu email, que enviaremos para você <br/> um link para redefinir sua senha!</p>
        </div>
        <div class="modal-body">
            <form class="form" method="post" action="{{ route('password.email') }}">
                @csrf
                    <div>
                        <div class="modal-body">
                            @include('alerts.success')
                            <div class="form-group">
                                <input  type="email" name="email" style="background-color: #E5E5E5;"
                                    class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}"
                                     value="{{ old('email') }}" placeholder="Digite seu email" required autofocus>
                                @include('alerts.feedback', ['field' => 'email'])
                            </div>
                        </div>
                        
                    </div>
                    <div class="d-flex justify-content-center" >
                        <button style="width: 300px;"
                        class="btn btn-lg btn-primary btn-block btn-login  font-weight-bold"
                        type="submit">Enviar link de Recuperação</button>
                    </div>
                </form>
          </div>
      </div>
    </div>
  </div>
  <!-- fim -->
<script>
    $('#rec').click(function() {
        $('#myModal').css('z-index', 3000);
    });
    $('#close').click(function() {
        $('#myModal').css('z-index', -3000);
    });
</script>
</html>
