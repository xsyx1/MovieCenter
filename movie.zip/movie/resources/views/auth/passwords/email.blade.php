@extends('layouts.app', ['class' => 'login-page', 'page' => _('Reset password'), 'contentClass' => 'login-page'])

@section('content')
<style>
    .login-heading {
    font-weight: bold;
    color: #C94A21;
    margin: 30px 0;
    font-size: 24px; 
    font-family: "Ubuntu", sans-serif;
    box-sizing: border-box;
}
    .btn-login {
            width: 80%;
            font-size: 12px;
            letter-spacing: 0.05rem;
            margin: 0px 30px 0px 30px;
            padding: 1rem 1rem;
            border-radius: 1,5rem;
            background: #C94A21;
            border-color: #C94A21;
        }

        .btn-login:hover {
            background: #C94A21;
            border-color: #C94A21;
        }
    </style>
    <div style="position: relative; left: 330px; " class="col-lg-5 col-md-7 ml-auto mr-auto">
        <form class="form" method="post" action="{{ route('password.email') }}">
            @csrf

            <div class="card">
                <div class="card-header">
                    <h4 style="box-sizing: border-box; color: #C94A21; font-family: '"ubuntu"', sans-serif;" class=" text-center login-heading mb-4">Recuperar Senha</h4>
                    <p style="font-weight: bold; font-size: 12px;font-family: '"ubuntu"', sans-serif;" class="text-center"><br/>Digite abaixo seu email, que enviaremos para você <br/> um link para redefinir sua senha!</p>
                </div>
                <div class="card-body">
                    @include('alerts.success')
                    <div class="form-label-group">
                        <input style="width: 80%; margin: 0px 30px 0px 30px;" type="email" name="email"
                            class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}"
                            placeholder="Email" value="{{ old('email') }}" required autofocus>
                        @include('alerts.feedback', ['field' => 'email'])
                    </div>
                </div>
                <div class="card-footer">
                    <button
                    class="btn btn-lg btn-primary btn-block btn-login  font-weight-bold"
                    type="submit">Enviar link de Recuperação</button>
                </div>
            </div>
        </form>
    </div>
@endsection
