<div class="row">
    <div class="col-md-6">
        {!!Form::text('name', 'Nome do Filme')
        ->required()
        !!}
    </div>
    <div class="col-md-3">
        {!!Form::select('genre', 'Gênero', ['' => 'Selecione'] + \App\Models\Movie::opGenre())
        ->value(isset($item->score) ? $item->genre : '')
        ->required()
        !!}
    </div>
    <div class="col-md-3">
        {!!Form::select('score', 'Nota', ['' => 'Selecione'] + \App\Models\Movie::opScore())
        ->value(isset($item->score) ? $item->score : '')
        ->required()
        !!}
    </div>
    <div class="col-md-3">
        {!!Form::date('date', 'Dt. de Lançamento')
        ->required()
        !!}
    </div>
    <div class="col-md-3">
        {!!Form::select('is_enabled', 'Ativo', [ 1 => 'Sim', 0 => 'Não'])
        ->value(isset($item) ? $item->is_enabled : 1)
        ->required()
        !!}
    </div>
</div>
<div class="row">
    <div class="col-12">
        <button type="submit" class="btn btn-dark float-right mt-4">Salvar</button>
    </div>
</div>
