@extends('layouts.app')

@section('content')
@include('alerts.success')
@include('alerts.error')
@endsection
