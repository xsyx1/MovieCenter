<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Movie extends Model
{
    protected $fillable = [
        'name', 'date', 'genre', 'score',
       'is_enabled'
    ];

    public function getInfoAttribute()
    {
        return $this->name;
    }

    public static function opScore($option = null)
    {
        $options = [
            1 => '1',
            2 => '2',
            3 => '3', 
            4 => '4', 
            5 => '5', 
            6 => '6', 
            7 => '7', 
            8 => '8', 
            9 => '9', 
            10 => '10'
        ];

        if (!$option)
            return $options;

        return $options[$option];
    }

    public static function opGenre($option = null)
    {
        $options = [
            0 => 'Selecione', 
            1 => 'Ação', 
            2 => 'Terror', 
            3 => 'Suspense', 
            4 => 'Drama', 
            5 => 'Comédia', 
            6 => 'Românce'
        ];

        if (!$option)
            return $options;

        return $options[$option];
    }
}
