<?php

namespace App\Http\Controllers\Admin;

use App\Models\Movie;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


class MovieController extends Controller
{
    public function index(Request $request)
    {
        $pesquisa = $request->criterio;
        $data = Movie::when(!empty($pesquisa), function ($query) use ($pesquisa) {
                return $query->where('name','like' , '%'. $pesquisa .'%');})
            ->orderBy('name', 'asc')
            ->paginate(10);

        return view('movies.index', compact('data'));
    }

    public function create()
    {
        return view('movies.create');
    }

    public function store(Request $request)
    {
        Validator::make(
            $request->all(),
            $this->rules($request)
        )->validate();


        $inputs = $request->all();
        Movie::create($inputs);

        return redirect()->route('movies.index')
            ->withStatus('Registro criado com sucesso.');
    }

    public function show($id)
    {
        $item = Movie::findOrFail($id);

        return view('movies.show', compact('item'));
    }

    public function edit($id)
    {
        $item = Movie::orderBy('name')->findOrFail($id);

        return view('movies.edit', compact('item'));
    }
   

    public function update(Request $request, $id)
    {
        $item = Movie::findOrFail($id);

        Validator::make(
            $request->all(),
            $this->rules($request, $item->getKey())
        )->validate();


        $item->fill($request->all())->save();

        return redirect()->route('movies.index')
            ->withStatus('Registro atualizado com sucesso.');
    }

    public function destroy($id)
    {
        $item = Movie::findOrFail($id);

        try {
            $item->delete();
            return redirect()->route('movies.index')
                ->withStatus('Registro deletado com sucesso.');
        } catch (\Exception $e) {
            return redirect()->route('movies.index')
                ->withError('Registro vinculado á outra tabela, somente poderá ser excluído se retirar o vinculo.');
        }
    }

    private function rules(Request $request, $primaryKey = null, bool $changeMessages = false)
    {
        $rules = [
            'name' => ['required'],
            'date' => ['required'],
            'genre' => ['required'],
            'score' => ['required']
        ];

        $messages = [];

        return !$changeMessages ? $rules : $messages;
    }
}
