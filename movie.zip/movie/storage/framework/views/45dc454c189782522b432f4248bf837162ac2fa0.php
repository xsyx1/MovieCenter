<?php $__env->startSection('content'); ?>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0">Filmes</h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('movies.index')); ?>" class="btn btn-sm btn-dark">Voltar</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php echo Form::open()
                    ->post()
                    ->route('movies.store')
                    ->multipart(); ?>

                    <div class="pl-lg-6">
                        <?php echo $__env->make('movies._forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => 'Filmes', 'pageSlug' => 'movies'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\movie\resources\views/movies/create.blade.php ENDPATH**/ ?>