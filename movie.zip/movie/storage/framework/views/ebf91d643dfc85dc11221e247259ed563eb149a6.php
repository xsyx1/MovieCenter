<?php $__env->startSection('content'); ?>
<style>
    .login-heading {
    font-weight: bold;
    color: #C94A21;
    margin: 30px 0;
    font-size: 24px; 
    font-family: "Ubuntu", sans-serif;
    box-sizing: border-box;
}
    .btn-login {
            width: 80%;
            font-size: 12px;
            letter-spacing: 0.05rem;
            margin: 0px 30px 0px 30px;
            padding: 1rem 1rem;
            border-radius: 1,5rem;
            background: #C94A21;
            border-color: #C94A21;
        }

        .btn-login:hover {
            background: #C94A21;
            border-color: #C94A21;
        }
    </style>
    <div style="position: relative; left: 330px; " class="col-lg-5 col-md-7 ml-auto mr-auto">
        <form class="form" method="post" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>

            <div class="card">
                <div class="card-header">
                    <h4 style="box-sizing: border-box; color: #C94A21; font-family: '"ubuntu"', sans-serif;" class=" text-center login-heading mb-4">Recuperar Senha</h4>
                    <p style="font-weight: bold; font-size: 12px;font-family: '"ubuntu"', sans-serif;" class="text-center"><br/>Digite abaixo seu email, que enviaremos para você <br/> um link para redefinir sua senha!</p>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="form-label-group">
                        <input style="width: 80%; margin: 0px 30px 0px 30px;" type="email" name="email"
                            class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                            placeholder="Email" value="<?php echo e(old('email')); ?>" required autofocus>
                        <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="card-footer">
                    <button
                    class="btn btn-lg btn-primary btn-block btn-login  font-weight-bold"
                    type="submit">Enviar link de Recuperação</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'login-page', 'page' => _('Reset password'), 'contentClass' => 'login-page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\track-master\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>