<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header">
                <div class="row">
                    <div class="col-8">
                        <h4 class="card-title">Filmes</h4>
                    </div>
                    <div class="col-4 text-right">
                        <a href="<?php echo e(route('movies.create')); ?>" class="btn btn-sm btn-dark">Adicionar Novo</a>
                    </div>
                </div>
            </div>
            <div class="card-body" style="z-index: 3000;">
                <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form class=" my-2 my-lg-0 justify-content-end"
					method="GET">
					<div class="row">
						<div class="col-md-8">
						<input class="form-control " type="text"
							name="criterio" maxlength="64"
							placeholder="Pesquisar" aria-label="Pesquisar">
						</div>
						<div class="col-md-4 d-flex justify-content-end">
							<br>
							<button class="btn btn-sm  btn-dark" type="submit">Filtrar</button>
							<a id="clear-filter" class="btn btn-sm  btn-default"
								href="<?php echo e(route('movies.index')); ?>"><i class="fa fa-eraser"></i>Limpar</a>
						</div>
					</div>
				</form>

                <div>
                    <table class="table tablesorter table-striped" id="">
                        <thead class=" text-primary">
                            <th scope="col">Nome</th>
                            <th scope="col">Data de Lançamento</th>
                            <th scope="col">Gênero</th>
                            <th scope="col">Nota</th>
                            <th scope="col" class="text-right">Ação</th>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->date); ?></td>
                                <td><?php echo e($item->opGenre($item->genre)); ?></td>
                                <td><?php echo e($item->score); ?></td>
                                <td class="text-right">
                                    <div class="dropdown">
                                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                            <form action="<?php echo e(route('movies.destroy', $item->id)); ?>" method="post"
                                                id="form-<?php echo e($item->id); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('movies.show', $item)); ?>">Visualizar</a>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('movies.edit', $item)); ?>">Editar</a>
                                                <button type="button" class="dropdown-item btn-delete">
                                                    Excluir
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="20" style="text-align: center; font-size: 1.1em;">
                                    Nenhuma informação cadastrada.
                                </td>
                            </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer py-4">
                <nav class="d-flex justify-content-end" aria-label="...">
                    <?php echo e($data->appends(request()->all())->links()); ?>

                </nav>
            </div>
        </div>
    </div>
</div>

<script>
$(".btn-delete").on("click", function (e) {
        var form = $(this).parents("form").attr("id");
        swal({
            title: "Você está certo?",
            text: "Uma vez deletado, você não poderá recuperar esse item novamente!",
            icon: "warning",
            buttons: true,
            buttons: ["Cancelar", "Excluir"],
            dangerMode: true,
        }).then((isConfirm) => {
            if (isConfirm) {
                document.getElementById(form).submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => 'Movie', 'pageSlug' => 'movies'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\movie\resources\views/movies/index.blade.php ENDPATH**/ ?>