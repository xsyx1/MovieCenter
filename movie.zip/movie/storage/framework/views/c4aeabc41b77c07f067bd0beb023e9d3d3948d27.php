<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="container">
				<div class="row">
					<div class="container">
						<div class="row">
						    <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                			<?php echo $__env->make('alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						    <div class="col-md-4">
						    	<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					    		<div class="card mb">
					              <img class="card-img-top" src="http://www.placehold.it/286x180" alt="Card image cap">
					              <div class="card-body mb">
					              <table>
					                <h5 class="text-center card-title"><?php echo e($item->name); ?></h5>
					                <hr>
					                <p class="text-center card-text"><?php echo e($item->total); ?></p>
					                <hr>
					                	<a class="btn btn-primary mb" type="button" href="<?php echo e(route('nfe.create', $item)); ?>">Comprar</a>
					            	</table>
					              </div>
					            </div>
					            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					            <div class=" col-md-12" style="display: flex; left: 100%">
					            	<div class="card-body mb">
                                		<h1 class="fas fa-ban"></h1>
                                		<h1 class="card-text" style="text-align: center; font-size: 1.1em;">
                                    		Nenhuma produto cadastrado.
                                		</h1>
                                	</div>
                            	</div>
                            <?php endif; ?>
					        </div>
						</div>
					</div>
				</div>
			</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\track-master\resources\views/dashboard.blade.php ENDPATH**/ ?>