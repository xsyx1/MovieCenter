<?php if(session($key ?? 'error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session($key ?? 'error')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <i class="tim-icons icon-simple-remove"></i>
    </button>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\track-master\resources\views/alerts/error.blade.php ENDPATH**/ ?>