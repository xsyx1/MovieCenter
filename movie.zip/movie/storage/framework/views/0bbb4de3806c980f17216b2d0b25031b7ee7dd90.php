<footer class="footer">
    <div class="container-fluid">
        <div class="copyright">
            © <?php echo e(date('Y')); ?> Copyright  Sabor e Saúde
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\movie\resources\views/layouts/footer.blade.php ENDPATH**/ ?>