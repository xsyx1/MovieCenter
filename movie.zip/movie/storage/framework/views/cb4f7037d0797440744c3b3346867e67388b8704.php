<?php if(session($key ?? 'error')): ?>
<div style="color: white" class="alert alert-danger alert-dismissible show" role="alert">
    <?php echo e(session($key ?? 'error')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <i class="tim-icons icon-simple-remove"></i>
    </button>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\movie\resources\views/alerts/error.blade.php ENDPATH**/ ?>