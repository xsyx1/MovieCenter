<?php


use App\Models\Person;
use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $person = Person::create([
            'name' => 'MovieCenter',
            'email' => 'movie@center.com',
            'nickname' => 'center',
            'nif' => '04496906000108',
            'phone' => '6332155400',
            'address' => 'Quadra 606 Sul, Al. Oscar Niemeyer, QI - 02, HM - 06, Lt. 02',
            'zip_code' => '77016524'
        ]);

        $user = User::create([
            'person_id' => $person->id,
            'email' => 'movie@center.com',
            'password' => bcrypt('1234567o')
        ]);


        $this->command->info('User ' . $user->name . ' created');
    }
}
